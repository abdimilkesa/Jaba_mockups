JABA MOCKUPS - TEST DOWNLOAD FILE

This is a TEST-ONLY archive to verify that the upload and download flow works.
It is not a real PSD mockup resource.

Contents:
- sample-design.svg: a simple sample design
- README.txt: this note

After uploading this ZIP in the admin dashboard, test the download button.
